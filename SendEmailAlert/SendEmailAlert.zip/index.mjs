import AWS from "aws-sdk";

export const handler = async (event) => {
  const sns = new AWS.SNS({ region: "ap-southeast-2" });

  // Create publish parameters
  var params = {
    Subject: "My first test message",
    Message:
      "This is my first test message from SNS. \n If you receive this message, then you have done a good job!",
    TopicArn: "arn:aws:sns:ap-southeast-2:975049932267:PictureUpload",
  };
  console.log("begin to send");

  try {
    const { MessageId } = await sns.publish(params).promise();
    console.log("finish");

    console.log(`Your message with id ${MessageId} has been delivered.`);
    return MessageId;
  } catch (e) {
    console.log("error");

    console.log(e);
    return e;
  }
  return { message: "done" };
};
